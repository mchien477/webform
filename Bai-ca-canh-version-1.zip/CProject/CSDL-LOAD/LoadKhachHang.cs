﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace CProject
{
    public class Load_KhachHang : QuanLyKetNoi
    {
        public int LaDangNhapThanhCong(string Username,string Password)
        {
            int flag = -1;
            Load_KhachHang dao = new Load_KhachHang();
            dao.Open();
            string qry = "SELECT * FROM KhachHang WHERE TenUser = '" + Username + "' AND PassUser ='" + Password + "'";
            SqlCommand cmd = new SqlCommand(qry, dao.cnn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                bool isAdmin = reader.GetBoolean(3);
                if (isAdmin == true)
                {
                    flag = 1;
                }
                else
                {
                    flag = 0;
                }
            }
            cmd.Dispose();
            reader.Dispose();
            dao.Close();
            return flag;
        }

        public bool NULL { get; set; }
    }
}