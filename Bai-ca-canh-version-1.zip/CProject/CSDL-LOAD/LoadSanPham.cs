﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

namespace CProject
{
    public class Load_SanPham : QuanLyKetNoi
    {
        public DataTable LoadSPTheoLoai(int MaLoai)
        {
            Load_SanPham dao_sp = new Load_SanPham();
            dao_sp.Open();
            string qry = "select *  from SanPham  where MaLoai = " + MaLoai;
            SqlCommand cmd = new SqlCommand(qry, dao_sp.cnn);
            SqlDataReader reader = cmd.ExecuteReader();
            DataTable dt = new DataTable();

            dt.Load(reader);

            cmd.Dispose();
            reader.Dispose();

            dao_sp.Close();

            return dt;

        }
        public SanPham LayThongTinSanPham(int ID)
        {
            Load_SanPham dao_sp = new Load_SanPham();
            dao_sp.Open();
            string qry = "select s.MaSP as MaSP,TenSP, Gia, HinhAnh, MaLoai, MoTa  from SanPham s where s.MaSP = " + ID;
            SqlCommand cmd = new SqlCommand(qry, dao_sp.cnn);
            SqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            SanPham sp = new SanPham();
            sp.MaSP = ID;
            sp.TenSP = reader.GetString(1);
            sp.Gia = int.Parse(reader["Gia"].ToString());
            sp.MaLoai = int.Parse(reader["MaLoai"].ToString());
            sp.MoTa = reader["MoTa"].ToString();
            sp.HinhAnh = reader["HinhAnh"].ToString();
            return sp;
        }
    }

}