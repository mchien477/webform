﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CProject
{
    public class SanPham
    {

        private int maSP;
        public int MaSP
        {
            get { return maSP; }
            set { maSP = value; }
        }

        private string tenSP;
        public string TenSP
        {
            get { return tenSP; }
            set { tenSP = value; }
        }

        private int gia;
        public int Gia
        {
            get { return gia; }
            set { gia = value; }
        }

        private int maLoai;
        public int MaLoai
        {
            get { return maLoai; }
            set { maLoai = value; }
        }

        private string moTa;
        public string MoTa
        {
            get { return moTa; }
            set { moTa = value; }
        }

        /*        private DateTime ngayNhap;

                public DateTime NgayNhap
                {
                    get { return ngayNhap; }
                    set { ngayNhap = value; }
                }
                private int soLuong;

                public int SoLuong
                {
                    get { return soLuong; }
                    set { soLuong = value; }
                }
         */

        private string hinhAnh;

        public string HinhAnh
        {
            get { return hinhAnh; }
            set { hinhAnh = value; }
        }

    }
}