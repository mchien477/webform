﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace CProject
{
    public class BUS_KhachHang
    {
        public int LaDangNhapThanhCong(string Username,string Password)
        {
            Load_KhachHang dao = new Load_KhachHang();
            return dao.LaDangNhapThanhCong(Username,Password);
        }
    }
}