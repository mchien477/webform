﻿// JavaScript Document


$(window).load(function () {
   
    $('#comment_click').click(function () {

        $('#form_comment').slideToggle();



    });
    

});
