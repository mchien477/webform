﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CProject
{
    public partial class sanpham : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadSanPham();
        }
        public void LoadSanPham()
        {
            if (Request.QueryString["ma"] != null)
            {
                int ulr = int.Parse(Request.QueryString["ma"].ToString());
                Session["ma"] = ulr;
                BUS_SanPham bus = new BUS_SanPham();
                switch (ulr)
                {
                    case 1:
                        dtlSanPham.DataSource = bus.LoadSanPhamTheoLoai(1);
                        dtlSanPham.DataBind();
                        Session["LoaiSP"] = "1";
                        break;
                    case 2:
                        dtlSanPham.DataSource = bus.LoadSanPhamTheoLoai(2);
                        dtlSanPham.DataBind();
                        Session["LoaiSP"] = "2";
                        break;
                    case 3:
                        dtlSanPham.DataSource = bus.LoadSanPhamTheoLoai(3);
                        dtlSanPham.DataBind();
                        Session["LoaiSP"] = "3";
                        break;
                    case 4:
                        dtlSanPham.DataSource = bus.LoadSanPhamTheoLoai(3);
                        dtlSanPham.DataBind();
                        Session["LoaiSP"] = "4";
                        break;
                    case 5:
                        dtlSanPham.DataSource = bus.LoadSanPhamTheoLoai(3);
                        dtlSanPham.DataBind();
                        Session["LoaiSP"] = "5";
                        break;
                    default:
                        break;
                }

            }
        }
    }
}