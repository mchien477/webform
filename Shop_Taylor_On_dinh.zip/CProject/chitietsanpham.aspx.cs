﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CProject
{
    public partial class chitietsanpham : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LayThongTinSanPham();
        }
        public void LayThongTinSanPham()
        {
            if (Request.QueryString["action"] == "chitiet")
            {
                int id = int.Parse(Request.QueryString["id"].ToString());
                Session["MaSP"] = id;
                BUS_SanPham bus = new BUS_SanPham();
                SanPham sp = new SanPham();
                sp = bus.LayThongTinSanPham(id);
                lbMaSP.Text = "Mã số sản phẩm: " + sp.MaSP.ToString();
                lblTenSP.Text = sp.TenSP;
                lblGiaBan.Text = "Giá : " + sp.Gia.ToString() + " VNĐ";
                imgSanPham.ImageUrl = sp.HinhAnh;
                pMoTa.InnerText = sp.MoTa;
            }


        }
    }
}