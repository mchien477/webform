﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace CProject
{
    public class BUS_SanPham
    {
        public DataTable LoadSanPhamTheoLoai(int LoaiSP)
        {
            Load_SanPham load = new Load_SanPham();
            return load.LoadSPTheoLoai(LoaiSP);
        }
        public SanPham LayThongTinSanPham(int ID)
        {
            Load_SanPham load = new Load_SanPham();

            return load.LayThongTinSanPham(ID);

        }
    }
}